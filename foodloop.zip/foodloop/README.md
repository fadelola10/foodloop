# FoodLoop

Application locale construite avec TanStack Start, React 19, Tailwind v4 et Supabase.

## Lancement local

1. Installe Bun : https://bun.sh/docs/installation
2. Dézippe le projet.
3. Dans le dossier du projet, lance :

```bash
bun install
bun dev
```

4. Ouvre http://localhost:8080

Le fichier `.env` est inclus dans l'archive pour que l'application puisse se connecter au backend immédiatement.

## Scripts

- `bun dev` — lancer le serveur local
- `bun run build` — générer la version production
- `bun run preview` — prévisualiser la version production
