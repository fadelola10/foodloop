import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Loader2, MapPin } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { AppShell, useCurrentUser } from "@/components/AppShell";
import type { Hub } from "@/lib/types";

export const Route = createFileRoute("/hubs")({
  head: () => ({ meta: [{ title: "FoodLoop — Hubs" }] }),
  component: HubsPage,
});

function HubsPage() {
  const { role } = useCurrentUser();
  const [hubs, setHubs] = useState<Hub[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const { data } = await supabase
        .from("hubs")
        .select("*")
        .eq("is_active", true)
        .order("city");
      setHubs((data as Hub[]) ?? []);
      setLoading(false);
    })();
  }, []);

  return (
    <AppShell role={role}>
      <h1 className="font-display text-3xl font-black">Hubs de retrait</h1>
      <p className="mt-1 text-sm text-muted-foreground">
        Récupérez vos commandes dans le hub le plus proche de chez vous.
      </p>

      {loading ? (
        <div className="flex justify-center py-12">
          <Loader2 className="size-6 animate-spin text-citrus" />
        </div>
      ) : hubs.length === 0 ? (
        <div className="mt-8 rounded-2xl border border-dashed border-border bg-card py-12 text-center text-sm text-muted-foreground">
          Aucun hub disponible pour le moment.
        </div>
      ) : (
        <div className="mt-6 grid gap-4 sm:grid-cols-2">
          {hubs.map((h) => (
            <div
              key={h.id}
              className="rounded-2xl border border-border bg-card p-5 transition-shadow hover:shadow-md"
            >
              <div className="flex items-start gap-3">
                <div className="flex size-10 shrink-0 items-center justify-center rounded-xl bg-citrus/15 text-amalfi">
                  <MapPin className="size-5" />
                </div>
                <div className="flex-1">
                  <h3 className="font-display text-lg font-bold">{h.name}</h3>
                  <p className="text-xs font-semibold uppercase tracking-wider text-citrus">
                    {h.city}
                  </p>
                  <p className="mt-1 text-sm text-muted-foreground">{h.address}</p>
                  {h.description && (
                    <p className="mt-2 text-xs text-muted-foreground">{h.description}</p>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </AppShell>
  );
}
