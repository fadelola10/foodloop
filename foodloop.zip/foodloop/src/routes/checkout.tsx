import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Loader2, CreditCard, CheckCircle2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { AppShell, useCurrentUser } from "@/components/AppShell";
import { getCartItems } from "@/lib/cart";
import { formatPrice, type Hub } from "@/lib/types";

export const Route = createFileRoute("/checkout")({
  head: () => ({ meta: [{ title: "FoodLoop — Commande" }] }),
  component: Checkout,
});

function Checkout() {
  const navigate = useNavigate();
  const { loading, userId, role } = useCurrentUser();
  const [items, setItems] = useState<Awaited<ReturnType<typeof getCartItems>>>([]);
  const [hubs, setHubs] = useState<Hub[]>([]);
  const [hubId, setHubId] = useState<string>("");
  const [notes, setNotes] = useState("");
  const [busy, setBusy] = useState(true);
  const [paying, setPaying] = useState(false);
  const [done, setDone] = useState<string | null>(null);

  useEffect(() => {
    if (loading) return;
    if (!userId) {
      navigate({ to: "/" });
      return;
    }
    (async () => {
      const [cart, hubsRes] = await Promise.all([
        getCartItems(userId),
        supabase.from("hubs").select("*").eq("is_active", true).order("name"),
      ]);
      setItems(cart);
      const h = (hubsRes.data as Hub[]) ?? [];
      setHubs(h);
      if (h[0]) setHubId(h[0].id);
      setBusy(false);
    })();
  }, [loading, userId]);

  const total = items.reduce((s, i) => s + i.quantity * i.products.price_cents, 0);

  async function pay() {
    if (!userId || items.length === 0 || !hubId) return;
    setPaying(true);
    try {
      // 1. Create order
      const { data: order, error: oErr } = await supabase
        .from("orders")
        .insert({
          user_id: userId,
          hub_id: hubId,
          total_cents: total,
          notes: notes || null,
          status: "paid", // paiement fictif: instantané
        })
        .select("id")
        .single();
      if (oErr) throw oErr;

      // 2. Create order items
      const orderItems = items.map((i) => ({
        order_id: order.id,
        product_id: i.products.id,
        product_name: i.products.name,
        unit_price_cents: i.products.price_cents,
        quantity: i.quantity,
        producer_id: i.products.producer_id,
      }));
      const { error: iErr } = await supabase.from("order_items").insert(orderItems);
      if (iErr) throw iErr;

      // 3. Decrement stock
      for (const i of items) {
        await supabase
          .from("products")
          .update({ stock: Math.max(0, i.products.stock - i.quantity) })
          .eq("id", i.products.id);
      }

      // 4. Clear cart
      const ids = items.map((i) => i.id);
      await supabase.from("cart_items").delete().in("id", ids);

      setDone(order.id);
    } catch (e) {
      alert("Erreur lors du paiement : " + (e as Error).message);
    } finally {
      setPaying(false);
    }
  }

  if (loading || busy) {
    return (
      <AppShell role={role}>
        <div className="flex justify-center py-12">
          <Loader2 className="size-6 animate-spin text-citrus" />
        </div>
      </AppShell>
    );
  }

  if (done) {
    return (
      <AppShell role={role}>
        <div className="mx-auto max-w-md py-12 text-center">
          <CheckCircle2 className="mx-auto size-16 text-emerald-500" />
          <h1 className="mt-4 font-display text-3xl font-black">Commande confirmée !</h1>
          <p className="mt-2 text-sm text-muted-foreground">
            Vous serez notifié quand elle sera prête à retirer.
          </p>
          <Link
            to="/app/orders/$orderId"
            params={{ orderId: done }}
            className="mt-6 inline-block rounded-xl bg-amalfi px-6 py-3 font-bold text-white"
          >
            Voir ma commande
          </Link>
        </div>
      </AppShell>
    );
  }

  if (items.length === 0) {
    return (
      <AppShell role={role}>
        <div className="mt-8 rounded-2xl border border-dashed border-border bg-card py-12 text-center">
          <p className="text-sm text-muted-foreground">Votre panier est vide.</p>
          <Link
            to="/catalogue"
            className="mt-4 inline-block rounded-xl bg-citrus px-5 py-2.5 text-sm font-bold text-white"
          >
            Voir le catalogue
          </Link>
        </div>
      </AppShell>
    );
  }

  return (
    <AppShell role={role}>
      <h1 className="font-display text-3xl font-black">Commande</h1>

      <div className="mt-6 grid gap-6 md:grid-cols-2">
        <section className="space-y-4">
          <div>
            <h2 className="font-display text-lg font-bold">Hub de retrait</h2>
            {hubs.length === 0 ? (
              <p className="mt-2 text-sm text-muted-foreground">Aucun hub disponible.</p>
            ) : (
              <div className="mt-2 space-y-2">
                {hubs.map((h) => (
                  <label
                    key={h.id}
                    className={
                      "flex cursor-pointer items-start gap-3 rounded-xl border p-3 " +
                      (hubId === h.id
                        ? "border-citrus bg-citrus/10"
                        : "border-border bg-card hover:bg-muted")
                    }
                  >
                    <input
                      type="radio"
                      checked={hubId === h.id}
                      onChange={() => setHubId(h.id)}
                      className="mt-1"
                    />
                    <div className="min-w-0">
                      <p className="font-semibold">{h.name}</p>
                      <p className="text-xs text-muted-foreground">
                        {h.address} · {h.city}
                      </p>
                    </div>
                  </label>
                ))}
              </div>
            )}
          </div>

          <div>
            <h2 className="font-display text-lg font-bold">Notes (optionnel)</h2>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={3}
              placeholder="Préférences, allergies…"
              className="mt-2 w-full rounded-xl border border-border bg-card px-3 py-2 text-sm"
            />
          </div>
        </section>

        <section>
          <div className="rounded-2xl border border-border bg-card p-5">
            <h2 className="font-display text-lg font-bold">Récapitulatif</h2>
            <ul className="mt-3 space-y-2 text-sm">
              {items.map((i) => (
                <li key={i.id} className="flex justify-between">
                  <span className="truncate">
                    {i.quantity} × {i.products.name}
                  </span>
                  <span className="font-semibold">
                    {formatPrice(i.quantity * i.products.price_cents)}
                  </span>
                </li>
              ))}
            </ul>
            <div className="mt-4 flex items-baseline justify-between border-t border-border pt-3">
              <span className="font-bold">Total</span>
              <span className="font-display text-2xl font-black text-amalfi">
                {formatPrice(total)}
              </span>
            </div>
          </div>

          <button
            onClick={pay}
            disabled={paying || !hubId}
            className="mt-4 flex w-full items-center justify-center gap-2 rounded-xl bg-citrus py-3.5 font-bold text-white disabled:opacity-60"
          >
            {paying ? (
              <Loader2 className="size-4 animate-spin" />
            ) : (
              <CreditCard className="size-4" />
            )}
            Payer (démo) — {formatPrice(total)}
          </button>
          <p className="mt-2 text-center text-xs text-muted-foreground">
            Paiement fictif pour démonstration. Aucun débit réel.
          </p>
        </section>
      </div>
    </AppShell>
  );
}
